package com.example.spinner123456;

public class villagemodel {


    int cityId,stateId,CountryId,villageId;
    String villageName;

    public villagemodel(int cityId, int stateId, int countryId,int villageId, String villageName) {
        this.cityId = cityId;
        this.stateId = stateId;
        this.villageId = villageId;
        CountryId = countryId;
        this.villageName = villageName;


    }

    public String getVillageName() {
        return villageName;
    }

}
