package com.example.spinner123456;

import java.util.ArrayList;

public class statemodel {
    int stateId, countryId,villageid;
    String stateName;
    ArrayList<citymodel> city;

    public statemodel(int stateId,int villageid, int countryId, String stateName, ArrayList<citymodel> city) {
        this.stateId = stateId;
        this.stateId = stateId;
        this.villageid = villageid;
        this.countryId = countryId;
        this.stateName = stateName;
        this.city = city;
    }


    public String getStateName() {
        return stateName;
    }

    public ArrayList<citymodel> getCity() {
        return city;
    }

}
