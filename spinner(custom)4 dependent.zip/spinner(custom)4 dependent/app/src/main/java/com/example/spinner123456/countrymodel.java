package com.example.spinner123456;

import java.util.ArrayList;

public class countrymodel {

        int countryId;
        String countryName;
        ArrayList<statemodel> state;

        public countrymodel(int countryId, String countryName, ArrayList<statemodel> state) {
            this.countryId = countryId;

            this.countryName = countryName;
            this.state = state;

    }
    public String getCountryName() {
        return countryName;
    }

    public ArrayList<statemodel> getState() {
        return state;
    }
}
