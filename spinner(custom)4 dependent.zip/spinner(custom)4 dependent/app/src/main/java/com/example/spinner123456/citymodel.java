package com.example.spinner123456;

import java.util.ArrayList;

public class citymodel {


    int cityId,stateId,CountryId,villageid;
    String cityName,villageName;
    ArrayList<villagemodel> village;

    public citymodel(int cityId, int stateId, int countryId,int villageid, String cityName,ArrayList<villagemodel>village) {
        this.cityId = cityId;
        this.stateId = stateId;
        this.villageid = villageid;
        CountryId = countryId;
        this.cityName = cityName;
        this.village = village;


    }

    public String getCityName() {
        return cityName;
    }
    public ArrayList<villagemodel> getvillage() {
        return village;
    }

}
